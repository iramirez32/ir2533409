/* 
 * File:   main.cpp
 * Author: Idalia Ramirez
 * Created on June 25, 2014, 7:14 PM
 */
#include <iostream>
using namespace std;

//System Libraries

//User Defined Libraries

//Global Constants

//Function Prototypes

//Execute Here!
int main(int argc, char** argv) {
    
    //Borderline of stars
    cout <<"********************************************\n";
    //Spaced out characters evenly to shape letters
    cout <<"     C C C          S S S S          !!\n";
    cout <<"    C     C        S        S        !!\n";
    cout <<"   C              S                  !!\n";
    cout <<"  C                S                 !!\n";
    cout <<"  C                 S S S S          !!\n";
    cout <<"  C                         S        !!\n";
    cout <<"   C                         S       !!\n";
    cout <<"    C      C       S         S   \n";
    cout <<"      C C C          S S S S         00\n";;
    //Borderline of stars
    cout <<"*******************************************\n";
    
    cout <<" Computer Science is Cool Stuff!!!\n";
    
    //End Here.
    return 0;
}

