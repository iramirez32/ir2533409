/* 
 * File:   main.cpp
 * Author: Idalia Ramirez
 * Created on June 26, 2014, 12:30 PM
 */
#include <iostream>
using namespace std;
//System Libraries

//User Defined Libraries

//Global Constants

//Function Prototypes

//Execute Here!
int main(int argc, char** argv) {
    //Define variables
    char ltr; //Short for letter
    
    cout<<"Enter your favorite letter.\n";
    cin>>ltr;
    
    cout<<"    "<<ltr<<" "<<ltr<<" "<<ltr<<endl;
    cout<<"   "<<ltr<<"     "<<ltr<<endl;
    cout<<"  "<<ltr<<endl;
    cout<<"  "<<ltr<<endl;
    cout<<"  "<<ltr<<endl;
    cout<<"  "<<ltr<<endl;
    cout<<"  "<<ltr<<endl;
    cout<<"   "<<ltr<<"     "<<ltr<<endl;
    cout<<"    "<<ltr<<" "<<ltr<<" "<<ltr<<"\n"<<endl;
    
    cout<<"Surprise. Carry on now.";

    //End Here.
    return 0;
}

